import pygame
import os
import random

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SPRITE_DIR = os.path.join(BASE_DIR, "sprites")

class Enemy:
    loaded_images = None
    boss_img = None

    def __init__(self, color, scale, x, y, is_boss=False):
        if Enemy.loaded_images is None:
            Enemy.loaded_images = [
                pygame.image.load(os.path.join(SPRITE_DIR, "paintballer.png")).convert_alpha(),
                pygame.image.load(os.path.join(SPRITE_DIR, "paintballer2.png")).convert_alpha(),
                pygame.image.load(os.path.join(SPRITE_DIR, "paintballer3.png")).convert_alpha(),
            ]
        if Enemy.boss_img is None:
            Enemy.boss_img = pygame.image.load(os.path.join(SPRITE_DIR, "painballerboss.png")).convert_alpha()

        self.color = color
        self.scale = scale
        self.x = x
        self.y = y
        self.is_boss = is_boss
        self.spawn_frame = 0
        self.hp = 10 if is_boss else 1

        self.image = Enemy.boss_img if is_boss else random.choice(Enemy.loaded_images)
        self.image = pygame.transform.scale(
            self.image,
            (int(self.image.get_width() * scale), int(self.image.get_height() * scale))
        )
        self._rect = self.image.get_rect(topleft=(x, y))

    def draw_self(self, screen):
        screen.blit(self.image, self._rect)

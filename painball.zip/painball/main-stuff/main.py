import pygame
import random
import splat
import background as bg
import enemy
import scoreboard as sb
import sys
from menu import main_menu
import os
from stats import GameStats

os.chdir(os.path.dirname(os.path.abspath(__file__)))

pygame.init()
pygame.mixer.init()

pygame.display.set_caption("Paintball")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

colors = [BLACK, RED, (0, 255, 0), (0, 0, 255), (255, 255, 0), (0, 255, 255), (255, 0, 255)]

splats = []
enemies = []
draw_objects = []
boss_spawned = False
game_stats = GameStats()
gun_sound = pygame.mixer.Sound("audio/paintball_gun.wav")
background = bg.Background(WHITE)
score = 0
scoreboard = sb.Scoreboard(score)

clock = pygame.time.Clock()
keep_playing = True

font = pygame.font.SysFont("arial", 28)


def draw_gradient_background(screen, top_color, bottom_color):
    for y in range(screen.get_height()):
        ratio = y / screen.get_height()
        r = top_color[0] * (1 - ratio) + bottom_color[0] * ratio
        g = top_color[1] * (1 - ratio) + bottom_color[1] * ratio
        b = top_color[2] * (1 - ratio) + bottom_color[2] * ratio
        pygame.draw.line(screen, (int(r), int(g), int(b)), (0, y), (screen.get_width(), y))


def draw_panel_text(text, pos, color):
    label = font.render(text, True, color)
    panel = pygame.Surface((label.get_width() + 20, label.get_height() + 10), pygame.SRCALPHA)
    panel.fill((0, 0, 0, 180))
    panel.blit(label, (10, 5))
    screen.blit(panel, pos)


def spawn_enemy(force_boss=False):
    global enemies, draw_objects, boss_active

    if force_boss:
        x = random.randint(0, screen_width - 100)
        y = random.randint(0, hud_top - 150)
        boss = enemy.Enemy(None, 2.0, x, y, is_boss=True)
        boss.spawn_frame = pygame.time.get_ticks()
        enemies.append(boss)
        draw_objects.append(boss)
        boss_active = True
    else:
        count = random.choices([1, 2, 3], weights=[85, 12, 3])[0]
        for _ in range(count):
            rand_scale = random.random() + 0.25
            x = random.randint(0, screen_width - 100)
            y = random.randint(0, hud_top - 150)
            new_enemy = enemy.Enemy(random.choice(colors[1:]), rand_scale, x, y)
            new_enemy.spawn_frame = pygame.time.get_ticks()
            enemies.append(new_enemy)
            draw_objects.append(new_enemy)


def main():
    global player_health, ammo, max_ammo, reloading, reload_timer, reload_time
    global splats, enemies, draw_objects, score, scoreboard
    global timer, enemy_lifetime, speed_multiplier, speedup_timer
    global keep_playing, hud_top, screen, screen_width, screen_height, selected_mode
    global boss_active
    global boss_spawned
    selected_mode, screen_width, screen_height = main_menu()
    screen = pygame.display.set_mode((screen_width, screen_height), pygame.SRCALPHA)
    print(f"[DEBUG] selected_mode: {selected_mode}, resolution: {screen_width}x{screen_height}")
    boss_active = False
    ammo_img = pygame.transform.scale(pygame.image.load("ammo.png").convert_alpha(), (32, 32))
    heart_img = pygame.transform.scale(pygame.image.load("heart.png").convert_alpha(), (32, 32))
    hud_top = screen_height - 200
    keep_playing = True
    boss_spawned = False
    splats.clear()
    enemies.clear()
    draw_objects.clear()
    show_name_input(screen)
    score = 0
    scoreboard = sb.Scoreboard(score)
    last_wave_time = pygame.time.get_ticks()
    enemy_lifetime = 1500
    speed_multiplier = 1
    speedup_timer = pygame.time.get_ticks()
    reloading = False
    reload_timer = 0
    reload_time = 60
    ammo = 10 if selected_mode != "Бесконечный режим" else None
    max_ammo = ammo

    if selected_mode == "Выживание (3 HP)":
        player_health = 3
    elif selected_mode == "Хардкор (1 HP)":
        player_health = 1
    else:
        player_health = None

    spawn_enemy()
    start_time = pygame.time.get_ticks()

    while keep_playing:
        current_time = pygame.time.get_ticks()
        screen.fill((30, 30, 30))

        if selected_mode == "Бесконечный режим":
            top_color, bottom_color = (20, 30, 40), (60, 70, 80)
        elif selected_mode in ["Выживание (3 HP)", "Выживание (1 HP)"]:
            top_color, bottom_color = (30, 20, 20), (120, 40, 40)
        else:
            top_color, bottom_color = (40, 20, 40), (100, 30, 80)

        draw_gradient_background(screen, top_color, bottom_color)
        hit_effect = False

        # Ускорение игры
        if current_time - speedup_timer >= 10000:
            speedup_timer = current_time
            if enemy_lifetime > 400:
                enemy_lifetime -= 100

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit();
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    show_pause_menu()
                elif event.key == pygame.K_r and not reloading and ammo is not None:
                    reloading = True
                    reload_timer = 0
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if selected_mode == "Бесконечный режим" or (ammo > 0 and not reloading):
                    if ammo is not None:
                        ammo -= 1
                    pygame.mixer.Sound.play(gun_sound)
                    mouse_pos = pygame.mouse.get_pos()
                    hit_effect = True
                    hit = False

                    for enemy_object in enemies:
                        if enemy_object._rect.collidepoint(mouse_pos):
                            enemy_object.hp -= 1
                            if enemy_object.hp <= 0:
                                splat_obj = splat.Splat(random.choice(colors), mouse_pos)
                                splats.append(splat_obj)
                                draw_objects.append(splat_obj)
                                elapsed = current_time - enemy_object.spawn_frame
                                score += max(100, (enemy_lifetime - elapsed) * 10) if not enemy_object.is_boss else 5000
                                scoreboard.update_score(score)
                                draw_objects.remove(enemy_object)
                                enemies.remove(enemy_object)
                                if enemy_object.is_boss:
                                    boss_active = False
                            hit = True
                            break

                    if hit and ammo is not None:
                        ammo += 1

        if current_time - last_wave_time >= enemy_lifetime:
            last_wave_time = current_time
            required_score = 300000
            if not boss_active and not boss_spawned and score >= required_score and all(not e.is_boss for e in enemies):
                spawn_enemy(force_boss=True)
                boss_spawned = True
            else:
                spawn_enemy()

        for enemy_object in enemies[:]:
            if current_time - enemy_object.spawn_frame >= enemy_lifetime:
                if player_health is not None:
                    player_health -= 1
                    enemies.remove(enemy_object)
                    draw_objects.remove(enemy_object)

                    if player_health <= 0:
                        keep_playing = False
                        break
                else:
                    enemies.remove(enemy_object)
                    draw_objects.remove(enemy_object)

        for obj in draw_objects:
            obj.draw_self(screen)

        hud_surface = pygame.Surface((screen_width, 96), pygame.SRCALPHA)
        hud_surface.fill((0, 0, 0, 180))
        screen.blit(hud_surface, (0, hud_top))
        pygame.draw.line(screen, (220, 220, 255), (0, hud_top), (screen_width, hud_top), 2)

        if ammo is not None:
            for i in range(ammo):
                screen.blit(ammo_img, (20 + i * 34, hud_top + 8))
            ammo_text = font.render(f"{ammo}", True, WHITE)
            screen.blit(ammo_text, (20 + ammo * 34 + 10, hud_top + 14))

        if player_health is not None:
            for i in range(player_health):
                screen.blit(heart_img, (20 + i * 38, hud_top + 48))
            hp_text = font.render(f"{player_health}", True, WHITE)
            screen.blit(hp_text, (20 + player_health * 38 + 10, hud_top + 54))

        draw_panel_text(f"След. волна: {max(0, (enemy_lifetime - (current_time - last_wave_time)) // 100)}",
                        (screen_width // 2 - 120, hud_top + 30), (200, 200, 255))
        draw_panel_text(f"Очки: {score}", (screen_width // 2 - 80, screen_height - 60), WHITE)

        if hit_effect:
            flash = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
            flash.fill((255, 255, 255, 50))
            screen.blit(flash, (0, 0))

        pygame.display.update()
        clock.tick(60)

    show_game_over()


def show_game_over():
    global screen, screen_width, screen_height, score, selected_mode

    game_stats.add_score(score, selected_mode)
    game_stats.export_stats()

    overlay = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
    screen.blit(overlay, (0, 0))

    font_big = pygame.font.SysFont("arial", 64)
    font_small = pygame.font.SysFont("arial", 32)
    text = font_big.render("Вы проиграли", True, WHITE)
    score_text = font_small.render(f"Ваш результат: {score}", True, WHITE)
    restart = font_small.render("Нажмите R — начать заново", True, WHITE)
    records = font_small.render("Нажмите T — таблица рекордов", True, WHITE)
    exit_menu = font_small.render("Нажмите M — выйти в меню", True, WHITE)

    screen.blit(text, text.get_rect(center=(screen_width // 2, screen_height // 2 - 120)))
    screen.blit(score_text, score_text.get_rect(center=(screen_width // 2, screen_height // 2 - 60)))
    screen.blit(restart, restart.get_rect(center=(screen_width // 2, screen_height // 2)))
    screen.blit(records, records.get_rect(center=(screen_width // 2, screen_height // 2 + 40)))
    screen.blit(exit_menu, exit_menu.get_rect(center=(screen_width // 2, screen_height // 2 + 80)))

    pygame.display.update()

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit();
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    main()
                elif event.key == pygame.K_m:
                    selected_mode, screen_width, screen_height = main_menu()
                    screen = pygame.display.set_mode((screen_width, screen_height), pygame.SRCALPHA)
                    main()
                elif event.key == pygame.K_t:
                    show_high_scores(screen)
                    show_game_over()  # Показываем снова экран окончания игры


def show_pause_menu():
    global screen, screen_width, screen_height

    overlay = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
    screen.blit(overlay, (0, 0))

    font_big = pygame.font.SysFont("arial", 48)
    font_small = pygame.font.SysFont("arial", 32)
    title = font_big.render("Пауза", True, WHITE)
    cont = font_small.render("P — продолжить", True, WHITE)
    exit_menu = font_small.render("M — в меню", True, WHITE)
    quit_game = font_small.render("Q — выход", True, WHITE)

    screen.blit(title, title.get_rect(center=(screen_width // 2, screen_height // 2 - 60)))
    screen.blit(cont, cont.get_rect(center=(screen_width // 2, screen_height // 2)))
    screen.blit(exit_menu, exit_menu.get_rect(center=(screen_width // 2, screen_height // 2 + 40)))
    screen.blit(quit_game, quit_game.get_rect(center=(screen_width // 2, screen_height // 2 + 80)))
    pygame.display.update()

    paused = True
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit();
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    paused = False
                elif event.key == pygame.K_m:
                    selected_mode, screen_width, screen_height = main_menu()
                    screen = pygame.display.set_mode((screen_width, screen_height), pygame.SRCALPHA)
                    main()
                elif event.key == pygame.K_q:
                    pygame.quit();
                    sys.exit()


def show_name_input(screen):
    input_active = True
    font = pygame.font.SysFont("arial", 32)

    while input_active:
        screen.fill((30, 30, 30))

        title = font.render("Введите ваше имя:", True, WHITE)
        screen.blit(title, (screen.get_width() // 2 - title.get_width() // 2, screen.get_height() // 2 - 50))

        input_rect = pygame.Rect(screen.get_width() // 2 - 150, screen.get_height() // 2, 300, 40)
        pygame.draw.rect(screen, WHITE, input_rect, 2)

        name_surface = font.render(game_stats.player_name, True, WHITE)
        screen.blit(name_surface, (input_rect.x + 5, input_rect.y + 5))

        start_button = pygame.Rect(screen.get_width() // 2 - 100, screen.get_height() // 2 + 60, 200, 50)
        pygame.draw.rect(screen, (0, 200, 0), start_button)
        start_text = font.render("Начать", True, BLACK)
        screen.blit(start_text, (start_button.x + 50, start_button.y + 10))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN and game_stats.player_name.strip():
                    input_active = False
                elif event.key == pygame.K_BACKSPACE:
                    game_stats.player_name = game_stats.player_name[:-1]
                else:
                    if len(game_stats.player_name) < 15:
                        game_stats.player_name += event.unicode
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(event.pos) and game_stats.player_name.strip():
                    input_active = False

        pygame.display.update()
        clock.tick(60)


def show_high_scores(screen):
    font_big = pygame.font.SysFont("arial", 48)
    font_small = pygame.font.SysFont("arial", 24)

    while True:
        screen.fill((30, 30, 30))

        title = font_big.render("Лучшие результаты", True, WHITE)
        screen.blit(title, (screen.get_width() // 2 - title.get_width() // 2, 50))

        y_pos = 120
        for i, record in enumerate(game_stats.get_top_scores(10)):
            text = f"{i + 1}. {record['name']}: {record['score']} ({record['mode']})"
            score_text = font_small.render(text, True, WHITE)
            screen.blit(score_text, (screen.get_width() // 2 - score_text.get_width() // 2, y_pos))
            y_pos += 30

        back_button = pygame.Rect(screen.get_width() // 2 - 100, screen.get_height() - 100, 200, 50)
        pygame.draw.rect(screen, (200, 0, 0), back_button)
        back_text = font_small.render("Назад", True, WHITE)
        screen.blit(back_text, (back_button.x + 70, back_button.y + 15))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back_button.collidepoint(event.pos):
                    return

        pygame.display.update()
        clock.tick(60)
# В stats.py добавьте метод для экспорта
def export_stats(self, filename='stats.json'):
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.high_scores, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Export error: {e}")
        return False

# Где-то при закрытии игры вызывайте:
game_stats.export_stats()



if __name__ == "__main__":
    main()
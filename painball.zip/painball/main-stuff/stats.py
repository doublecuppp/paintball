import json
import os
from datetime import datetime


class GameStats:
    def __init__(self):
        self.high_scores = []
        self.player_name = ""
        self.load_high_scores()

    def load_high_scores(self):
        try:
            if os.path.exists('highscores.json'):
                with open('highscores.json', 'r', encoding='utf-8') as f:
                    self.high_scores = json.load(f)
        except Exception as e:
            print(f"Error loading highscores: {e}")
            self.high_scores = []

    def save_high_scores(self):
        try:
            with open('highscores.json', 'w', encoding='utf-8') as f:
                json.dump(self.high_scores, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving highscores: {e}")

    def add_score(self, score, game_mode):
        if not self.player_name.strip():
            return

        new_score = {
            "name": self.player_name,
            "score": score,
            "mode": game_mode,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        self.high_scores.append(new_score)
        self.high_scores.sort(key=lambda x: x["score"], reverse=True)
        self.high_scores = self.high_scores[:10]
        self.save_high_scores()

    def get_top_scores(self, count=10):
        return self.high_scores[:count]

    def export_stats(self, filename='stats.json'):
        """Экспорт статистики в файл для сайта"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(self.high_scores, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Export error: {e}")
            return False
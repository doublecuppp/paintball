import pygame
import sys
import os
import webbrowser
from stats import GameStats

game_stats = GameStats()

os.environ['SDL_VIDEO_CENTERED'] = '1'
pygame.init()

# --- Настройки ---
screen_modes = {
    "Высокое (1920x1080)": (1920, 1080),
    "Среднее (1280x720)": (1280, 720),
    "Низкое (800x600)": (800, 600)
}
current_mode = "Высокое (1920x1080)"
music_volume = 0.5

bg_image = pygame.image.load("menu.png")
font = pygame.font.SysFont("arial", 40)
small_font = pygame.font.SysFont("arial", 24)


def draw_fancy_button(surface, text, center_pos, selected=False, width=400, height=70):
    x, y = center_pos
    rect = pygame.Rect(0, 0, width, height)
    rect.center = (x, y)
    color = (255, 255, 100) if selected else (30, 30, 30)
    pygame.draw.rect(surface, color, rect, border_radius=20)
    pygame.draw.rect(surface, (255, 255, 255), rect, width=2, border_radius=20)
    txt_surface = font.render(text, True, (0, 0, 0))
    surface.blit(txt_surface, txt_surface.get_rect(center=rect.center))
    return rect


def rect_collide(mouse, center, w=400, h=70):
    rect = pygame.Rect(0, 0, w, h)
    rect.center = center
    return rect.collidepoint(mouse)


def show_high_scores(screen):
    while True:
        # Очищаем экран
        screen.blit(pygame.transform.scale(bg_image, screen.get_size()), (0, 0))

        # Заголовок
        title = font.render("Лучшие результаты", True, (255, 255, 255))
        screen.blit(title, (screen.get_width() // 2 - title.get_width() // 2, 50))

        # Получаем и отображаем рекорды
        y_pos = 120
        for i, record in enumerate(game_stats.get_top_scores()):
            text = f"{i + 1}. {record['name']}: {record['score']} ({record['mode']})"
            score_text = small_font.render(text, True, (255, 255, 255))
            screen.blit(score_text, (screen.get_width() // 2 - score_text.get_width() // 2, y_pos))
            y_pos += 40

        # Кнопка "Назад"
        back_button = draw_fancy_button(screen, "Назад", (screen.get_width() // 2, screen.get_height() - 100))

        # Обновление экрана
        pygame.display.update()

        # Обработка событий
        mouse = pygame.mouse.get_pos()
        click = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                click = True

        if back_button.collidepoint(mouse) and click:
            return

        pygame.time.Clock().tick(60)


def main_menu():
    global current_mode, music_volume
    screen = pygame.display.set_mode(screen_modes[current_mode])
    pygame.display.set_caption("Меню")
    menu_state = "main"
    modes = list(screen_modes.keys())

    while True:
        screen.blit(pygame.transform.scale(bg_image, screen.get_size()), (0, 0))
        mouse = pygame.mouse.get_pos()
        click = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                click = True

        if menu_state == "main":
            buttons = [
                ("Начать игру", (screen.get_width() // 2, 200)),
                ("Статистика", (screen.get_width() // 2, 290)),
                ("Настройки", (screen.get_width() // 2, 380)),
                ("Узнать больше", (screen.get_width() // 2, 470)),
                ("Выход", (screen.get_width() // 2, 560))
            ]

            # Сначала создаем все кнопки
            button_rects = []
            for text, pos in buttons:
                rect = draw_fancy_button(screen, text, pos, selected=rect_collide(mouse, pos))
                button_rects.append((text, rect))

            # Затем проверяем клики
            for text, rect in button_rects:
                if rect.collidepoint(mouse) and click:
                    if text == "Начать игру":
                        return show_mode_selection(screen)
                    elif text == "Статистика":
                        show_high_scores(screen)
                        screen.blit(pygame.transform.scale(bg_image, screen.get_size()), (0, 0))
                        pygame.display.update()
                    elif text == "Настройки":
                        menu_state = "settings"
                    elif text == "Узнать больше":
                        webbrowser.open("file:///Z:/%D0%93%D1%80%D1%83%D0%BF%D0%BF%D1%8B/%D0%98%D0%A1-141/%D0%90%D0%BD%D0%B4%D1%80%D0%B0%D1%85%D0%B0%D0%BD%D0%BE%D0%B2/site/index.html")
                    elif text == "Выход":
                        pygame.quit()
                        sys.exit()

        elif menu_state == "settings":
            draw_fancy_button(screen, "Громкость: {}%".format(int(music_volume * 100)), (screen.get_width() // 2, 200))
            y_start = 280
            for i, mode in enumerate(modes):
                rect = draw_fancy_button(screen, mode, (screen.get_width() // 2, y_start + i * 80),
                                         selected=(mode == current_mode))
                if rect.collidepoint(mouse) and click:
                    current_mode = mode
                    screen = pygame.display.set_mode(screen_modes[current_mode])

            back_rect = draw_fancy_button(screen, "Назад", (screen.get_width() // 2, y_start + len(modes) * 80 + 50))
            if back_rect.collidepoint(mouse) and click:
                menu_state = "main"

        pygame.display.update()
        pygame.time.Clock().tick(60)


def show_mode_selection(screen):
    modes = [
        ("Бесконечный режим", (screen.get_width() // 2, 250)),
        ("Выживание (3 HP)", (screen.get_width() // 2, 340)),
        ("Хардкор (1 HP)", (screen.get_width() // 2, 430)),
        ("Назад", (screen.get_width() // 2, 520)),
    ]

    while True:
        screen.blit(pygame.transform.scale(bg_image, screen.get_size()), (0, 0))
        mouse = pygame.mouse.get_pos()
        click = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                click = True

        for name, pos in modes:
            rect = draw_fancy_button(screen, name, pos, selected=rect_collide(mouse, pos))
            if rect.collidepoint(mouse) and click:
                if name == "Назад":
                    return main_menu()
                return name, *screen_modes[current_mode]

        pygame.display.update()
        pygame.time.Clock().tick(60)